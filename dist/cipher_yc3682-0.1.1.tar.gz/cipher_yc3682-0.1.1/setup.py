# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cipher_yc3682']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'cipher-yc3682',
    'version': '0.1.1',
    'description': '',
    'long_description': None,
    'author': 'yunxuan0724',
    'author_email': 'yc3682@columbia.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.5,<4.0',
}


setup(**setup_kwargs)
